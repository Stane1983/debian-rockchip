var searchData=
[
  ['rc4_0',['RC4',['../group__lavu__rc4.html',1,'']]],
  ['reading_20option_20values_1',['Reading option values',['../group__opt__read.html',1,'']]],
  ['riff_20fourccs_2',['RIFF FourCCs',['../group__riff__fourcc.html',1,'']]],
  ['ripemd_3',['RIPEMD',['../group__lavu__ripemd.html',1,'']]]
];

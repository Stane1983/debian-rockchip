var searchData=
[
  ['parameter_20definition_0',['Parameter Definition',['../group__lavu__iamf__params.html',1,'']]],
  ['pixel_20formats_1',['Pixel formats',['../group__lavc__misc__pixfmt.html',1,'']]],
  ['preprocessor_20string_20macros_2',['Preprocessor String Macros',['../group__preproc__misc.html',1,'']]],
  ['public_20metadata_20api_3',['Public Metadata API',['../group__metadata__api.html',1,'']]]
];

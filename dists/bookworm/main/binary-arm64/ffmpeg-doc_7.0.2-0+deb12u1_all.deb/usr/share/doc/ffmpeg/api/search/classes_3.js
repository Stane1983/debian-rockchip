var searchData=
[
  ['fftcomplex_0',['FFTComplex',['../structFFTComplex.html',1,'']]],
  ['filteringcontext_1',['FilteringContext',['../structFilteringContext.html',1,'']]]
];
